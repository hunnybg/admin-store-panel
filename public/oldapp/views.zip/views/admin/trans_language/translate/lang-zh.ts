// lang-zh.ts

export const LANG_ZH_NAME = 'zh';

export const LANG_ZH_TRANS = {
    'hello world': '你好，世界',
    'hi':'嗨',
    'dashboard':'仪表板'
    
};